# cALorie RepCount-A training v2 (50% RepCount cap), stage A

Classifier and gates retrained with RepCount train clips; scored on RepCount dev clips and the internal test. The sealed test and locked benchmark were not read. Non-promotable. Verdict: stage_a_pass
