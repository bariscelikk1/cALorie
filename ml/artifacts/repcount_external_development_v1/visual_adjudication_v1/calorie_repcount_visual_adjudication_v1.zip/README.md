# RepCount visual adjudication packet v1

Eight medium-confidence rows from the Notebook 37 post-run audit. Review the silent 240p previews together with dense 4 FPS sheets. No source video, training, model score, or final adjudication is included. The stuN token is not a verified person identity.
