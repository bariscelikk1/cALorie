# cALorie RepCount external development intake v1

Thirty pinned RepCount-A clips from ten people were fetched without YouTube or manual uploads. The frozen V6-F model was scored inside published repetition-cycle bounds. Results are provisional source-shift diagnostics, not locked-benchmark accuracy. No training, calibration, threshold tuning, or locked benchmark access occurred. Raw videos are intentionally excluded.
