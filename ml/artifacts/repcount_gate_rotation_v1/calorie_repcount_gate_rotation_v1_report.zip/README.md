# cALorie RepCount gate rotation v1

Gate-only retraining with RepCount clips outside each scored source-group fold. Classifier, fusion, and threshold 0.65 were frozen. Control = Notebook 31 archived gates. The locked creator benchmark was not read. Non-promotable development evidence. Verdict: data_effect_not_supported
