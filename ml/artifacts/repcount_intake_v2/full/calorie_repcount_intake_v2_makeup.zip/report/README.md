# cALorie RepCount-A intake v2 evidence, shard makeup

Pose, contact sheets, and scene thumbnails for 5 clips. No labels, training, model scoring, or locked-benchmark access. Raw video is excluded. Clips with errors: 1 (see source_audit.csv).
