# cALorie RepCount-A intake v2 pilot evidence

Pose, contact sheets, and scene thumbnails for 64 pilot clips, plus scene thumbnails for the 30 v1 clips. No labels, training, model scoring, or locked-benchmark access. Raw video is excluded. Clips with errors: 0 (see source_audit.csv).
