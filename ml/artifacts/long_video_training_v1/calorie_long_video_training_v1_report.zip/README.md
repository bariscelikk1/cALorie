# cALorie long-video training v1 (Notebook 45)

v2 recipe plus the 11 long-video train videos' windows; control is frozen v2. Scored on the 5 dev videos (full-session scorer, smoothed) and the internal test. No locked or sealed test was read. Non-promotable. Verdict: dev_fail
