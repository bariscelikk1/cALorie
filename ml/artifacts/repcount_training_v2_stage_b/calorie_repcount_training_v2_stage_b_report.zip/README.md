# cALorie RepCount-A training v2 (50% RepCount cap), stage B: sealed test

Frozen v2 stage-A models scored once on the RepCount sealed test and the internal test. No training. The locked benchmark was not read. Non-promotable. Verdict: stage_b_fail
